#' @importFrom stats sd aggregate shapiro.test ks.test t.test chisq.test var.test setNames
#' @importFrom utils globalVariables
#' @importFrom dplyr %>%
NULL
