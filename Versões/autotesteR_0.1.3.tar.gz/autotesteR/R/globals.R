# R/globals.R

if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("grupo", "ind", "letra", "n", "p adj", "p.adj", "prop", "valor", "values"))
}

